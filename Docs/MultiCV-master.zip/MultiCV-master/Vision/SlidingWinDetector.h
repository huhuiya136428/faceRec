#ifndef SLIDINGWINDETECTOR_H
#define SLIDINGWINDETECTOR_H

#include "Vision/AlgoVision.h"
#include <iostream>
#include <omp.h>

using namespace std;

class SlidingWinDetector : public AlgoVision
{
public:
    SlidingWinDetector();
};

#endif // SLIDINGWINDETECTOR_H
