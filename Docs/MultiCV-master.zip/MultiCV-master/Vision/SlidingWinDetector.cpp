#include "SlidingWinDetector.h"

SlidingWinDetector::SlidingWinDetector()
{
}
