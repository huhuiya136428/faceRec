#include "EventData.h"

EventData::EventData()
{
}
