#ifndef EVENTDATA_H
#define EVENTDATA_H

class EventData
{
public:
    virtual ~EventData() {}
};

#endif // EVENTDATA_H
