#include "AlgoSettings.h"

AlgoSettings::AlgoSettings()
{
}
